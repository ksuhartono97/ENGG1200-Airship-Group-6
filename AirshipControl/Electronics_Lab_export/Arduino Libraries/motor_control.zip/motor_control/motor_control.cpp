#include <motor_control.h>
#include <BT_timer.h>

int motorsIndex[8] = {5,3,9,6,11,10,12,13};
int dirIndex[8] = {5,4,3,2,1,0,7,8};

void motor_control_init(void){  
	pinMode(7, OUTPUT);  
	pinMode(8, OUTPUT);  
	pinMode(12, OUTPUT);  
	pinMode(13, OUTPUT);
	PORTC &= ~(_BV(PORTC0) | _BV(PORTC1) | _BV(PORTC2) | _BV(PORTC3) | _BV(PORTC4) | _BV(PORTC5));
	DDRC |= _BV(PORTC0) | _BV(PORTC1) | _BV(PORTC2) | _BV(PORTC3) | _BV(PORTC4) | _BV(PORTC5);  
	TCCR0B &= ~(_BV(CS00) | _BV(CS01));
	TCCR0B |= _BV(CS02);
}

void motor_start(int index, int vel){
	startTimer();                         // Restart the timer
	if(index >= 0 && index <= 7 && vel <= 255 && vel >= -255){
		int dir = vel < 0 ? 1 : 0;
		if(dir){
			vel = -vel;
		}  
		if(index >= 0 && index <= 5){
			analogWrite(motorsIndex[index], vel);
		}
		else if(index >= 6){
			if(vel == 0){
				digitalWrite(motorsIndex[index], LOW);
			}
			else{
				digitalWrite(motorsIndex[index], HIGH);
			}
		}
		if(dir){
			if(index >= 6){				
				digitalWrite(dirIndex[index], HIGH);
			}
			else{
				PORTC &= ~_BV(dirIndex[index]);
			}
		}
		else{
			if(index >= 6){				
				digitalWrite(dirIndex[index], LOW);
			}
			else{
				PORTC |= _BV(dirIndex[index]);
			}
		}
		if(dir){
			vel = -vel;
		}  
		Serial.write("motor:");	
		Serial.print(index, DEC);
		Serial.write("\tvelocity:");
		Serial.println(vel, DEC);
	}
}
 
void stop_all(void){
	for(int i = 0; i < 6; i++){
		analogWrite(motorsIndex[i], MIN_DUTY_CYCLE);
	}  
	digitalWrite(motorsIndex[6], LOW);
	digitalWrite(motorsIndex[7], LOW);  
}