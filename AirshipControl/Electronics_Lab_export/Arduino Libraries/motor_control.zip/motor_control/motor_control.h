#ifndef __MOTOR_CONTROL_H
#define __MOTOR_CONTROL_H

#include <Arduino.h>

#define MIN_DUTY_CYCLE  0
#define MAX_DUTY_CYCLE  255
#define RANGE  MAX_DUTY_CYCLE - MIN_DUTY_CYCLE

#define MIN_DUTY_CYCLE1  140
#define MIN_DUTY_CYCLE2  70
#define MAX_DUTY_CYCLE1  190
#define MAX_DUTY_CYCLE2  95
#define RANGE1  MAX_DUTY_CYCLE1 - MIN_DUTY_CYCLE1
#define RANGE2  MAX_DUTY_CYCLE2 - MIN_DUTY_CYCLE2

void motor_control_init(void);
void motor_start(int index, int vel);
void stop_all(void);

#endif