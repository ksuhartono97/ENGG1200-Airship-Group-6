#ifndef	__COMMUNICATION_H
#define	__COMMUNICATION_H

#include <Arduino.h>
#include <motor_control.h>

void comm_init(void);
void execute_cmd(int cmd, int value);

#endif