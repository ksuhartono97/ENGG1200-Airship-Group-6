#include <communication.h>
#include <motor_control.h>

int buf[4] = {-1,-1,-1,-1}, counter = 0;

void comm_init(void){
  Serial.begin(115200);
}

void serialEvent(){ 
  if(Serial.available()){
    int temp = -1;
    do{
      temp = Serial.read(); //Return a character that was received on the RX pin
			    //return -1 if nothing can be read from the receive buffer
      if(temp != -1){
        buf[counter] = temp;
        if(counter++ >= 3 || buf[0] != '$'){
          counter = 0;
          if(buf[0] == '$' && buf[3] == '\n'){
			int cmd, value;
            uint16_t raw_data = (buf[1] << 8) | buf[2];
			cmd = (raw_data & 0xfe00) >> 9;
            value = (raw_data & 0x01ff);
			value -= 256;
            execute_cmd(cmd, value);
          }
          for(int i = 0; i < 4; i++){
            buf[i] = -1;
          }
       }
     }
   }while(temp != -1);
  }
}